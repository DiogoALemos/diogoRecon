#!/bin/bash

function Sublist {

	
mkdir relatorio_Sub	


echo "Insira o domain que deseja analisar"
read domain

python3 sublist3r.py -v -o scan.txt -d $domain

echo "Insira os ports que deseja analisar"
read port

python3 sublist3r.py -v -o port.txt -d $domain -p $port

cp ports.txt relatorio_Sub
cp scan.txt relatorio_Sub

rm scan.txt
rm port.txt
}

Sublist


